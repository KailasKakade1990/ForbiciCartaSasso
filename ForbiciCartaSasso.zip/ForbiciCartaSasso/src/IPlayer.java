/**
 * 
 * 
 * @author Kailas Kakade
 */
public interface IPlayer {
	
	public Symbol move();

}
